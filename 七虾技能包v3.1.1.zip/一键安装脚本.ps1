﻿$ErrorActionPreference="Stop"
Write-Host "╔═══════════════════════════════════════╗" -ForegroundColor Cyan
Write-Host "║     七虾技能包 v3.1.1 一键安装       ║" -ForegroundColor Cyan
Write-Host "╚═══════════════════════════════════════╝" -ForegroundColor Cyan
$d=Split-Path -Parent $MyInvocation.MyCommand.Definition
if(-not(Test-Path "$d\skills")){Write-Host "错误: 找不到 skills/ 文件夹" -ForegroundColor Red;Read-Host "回车退出";exit 1}
$t=@("$env:USERPROFILE\.openclaw\skills","$env:USERPROFILE\.openclaw\workspace\.agents\skills")
foreach($x in $t){if(-not(Test-Path $x)){New-Item -ItemType Directory -Path $x -Force|Out-Null};Copy-Item -Path "$d\skills\*" -Destination $x -Recurse -Force;Write-Host "  -> $x" -ForegroundColor Green}
$e="F:\My_WenAn\OpenClaw-File\七虾技能包v3.1.1\外部依赖"
if(Test-Path "F:\"){if(-not(Test-Path $e)){New-Item -ItemType Directory -Path $e -Force|Out-Null};Copy-Item -Path "$d\外部依赖\*" -Destination $e -Recurse -Force;Write-Host "  -> 外部依赖" -ForegroundColor Green}
Write-Host "`n✅ 安装完成！请重启 OpenClaw。" -ForegroundColor Green
Write-Host "使用：发微信「七虾全自动 帮我写一篇关于XX的文章」" -ForegroundColor Yellow
Read-Host "`n按回车退出"