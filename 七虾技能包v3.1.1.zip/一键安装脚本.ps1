$ErrorActionPreference="Stop"
Write-Host "七虾技能包 v3.1.1 安装中..." -ForegroundColor Cyan
$d=Split-Path -Parent $MyInvocation.MyCommand.Definition
if(-not(Test-Path "$d\skills")){Write-Host "错误: 找不到 skills/ 文件夹" -ForegroundColor Red;Read-Host "回车退出";exit 1}
$t=@("$env:USERPROFILE\.openclaw\skills","$env:USERPROFILE\.openclaw\workspace\.agents\skills")
foreach($x in $t){if(-not(Test-Path $x)){mkdir $x -Force|Out-Null};Copy-Item -Path "$d\skills\*" -Destination $x -Recurse -Force;Write-Host "  -> $x" -ForegroundColor Green}
$e="F:\My_WenAn\OpenClaw-File\七虾技能包v3.1.1\外部依赖"
if(Test-Path "F:\"){if(-not(Test-Path $e)){mkdir $e -Force|Out-Null};Copy-Item -Path "$d\外部依赖\*" -Destination $e -Recurse -Force}
Write-Host "`n完成！重启OpenClaw后使用。" -ForegroundColor Green
Read-Host "回车退出"