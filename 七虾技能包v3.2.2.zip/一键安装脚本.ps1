# 七虾技能包 v3.2.2 — 一键安装脚本

# 使用方法：右键 → "使用PowerShell运行"

$ErrorActionPreference = "Stop"
Write-Host "七虾技能包 v3.2.2 安装开始..." -ForegroundColor Cyan

# 获取当前脚本所在目录
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# 目标路径
$openclawSkillsDir = "$env:USERPROFILE\.openclaw\workspace\.agents\skills"
$workspaceSkillsDir = "$env:USERPROFILE\.openclaw\workspace\.agents\skills"

# 确认目标路径存在
if(!(Test-Path $openclawSkillsDir)) {
    New-Item -Path $openclawSkillsDir -ItemType Directory -Force | Out-Null
    Write-Host "  创建目录: $openclawSkillsDir" -ForegroundColor Yellow
}

# 技能列表
$skills = @("xuan-ti-xia","kuang-jia-xia","da-gang-xia","wen-an-xia","biao-ti-xia","tu-pian-xia","shen-he-xia","qi-xia-quan-liu-cheng")

# 复制技能文件
Write-Host "`n复制技能文件..." -ForegroundColor Cyan
foreach($s in $skills) {
    $src = "$scriptDir\skills\$s"
    $dst = "$openclawSkillsDir\$s"
    if(Test-Path $src) {
        if(!(Test-Path $dst)) { New-Item -Path $dst -ItemType Directory -Force | Out-Null }
        Copy-Item "$src\SKILL.md" "$dst\SKILL.md" -Force
        $ver = (Select-String "$dst\SKILL.md" -Pattern "^version:").Line.Split(':')[1].Trim().Replace('"','')
        Write-Host "  ✅ $s v$ver" -ForegroundColor Green
    }
}

# 复制外部依赖
Write-Host "`n复制外部依赖文件..." -ForegroundColor Cyan
$depSrc = "$scriptDir\外部依赖"
$depDst = "$openclawSkillsDir\外部依赖"
if(Test-Path $depSrc) {
    if(!(Test-Path $depDst)) { New-Item -Path $depDst -ItemType Directory -Force | Out-Null }
    Copy-Item "$depSrc\*.md" "$depDst\" -Force
    Get-ChildItem $depDst -Filter "*.md" | ForEach-Object { Write-Host "  ✅ $($_.Name)" -ForegroundColor Green }
}

# 版本历史
Write-Host "`n写入版本信息..." -ForegroundColor Cyan
$verFile = "$openclawSkillsDir\外部依赖\七虾版本历史.json"
if(Test-Path "$scriptDir\外部依赖\七虾版本历史.json") {
    Copy-Item "$scriptDir\外部依赖\七虾版本历史.json" $verFile -Force
}

Write-Host "`n============================" -ForegroundColor Cyan
Write-Host " 七虾技能包 v3.2.2 安装完成!" -ForegroundColor Green
Write-Host "============================" -ForegroundColor Cyan
Write-Host "`n包含 8 个技能 + 4 个外部依赖文件"
Write-Host "重启 OpenClaw 后即可使用。"
Write-Host "`n使用方式："
Write-Host "  全自动：说'七虾全流程，写一篇XX文章'"
Write-Host "  手动：说'七虾手动，写一篇XX文章'"
Write-Host "`n有任何问题请联系：民哥"
